/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 50520
Source Host           : localhost:3306
Source Database       : library

Target Server Type    : MYSQL
Target Server Version : 50520
File Encoding         : 65001

Date: 2021-03-11 19:53:30
*/

drop database if exists library;
create database library charset utf8;
use library;

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admins
-- ----------------------------
DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(20) DEFAULT NULL,
  `code` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admins
-- ----------------------------
INSERT INTO `admins` VALUES ('1', '汤姆', 'tom', '123');
INSERT INTO `admins` VALUES ('2', '杰克', 'jack', '123');

-- ----------------------------
-- Table structure for backs
-- ----------------------------
DROP TABLE IF EXISTS `backs`;
CREATE TABLE `backs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brid` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `borrows_id` (`brid`),
  CONSTRAINT `borrows_id` FOREIGN KEY (`brid`) REFERENCES `borrows` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of backs
-- ----------------------------
INSERT INTO `backs` VALUES ('12', '14', '2');
INSERT INTO `backs` VALUES ('13', '15', '0');
INSERT INTO `backs` VALUES ('14', '16', '0');
INSERT INTO `backs` VALUES ('15', '18', '0');
INSERT INTO `backs` VALUES ('16', '17', '0');

-- ----------------------------
-- Table structure for books
-- ----------------------------
DROP TABLE IF EXISTS `books`;
CREATE TABLE `books` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bname` varchar(20) DEFAULT NULL,
  `sid` int(11) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `author` varchar(20) DEFAULT NULL,
  `birth` varchar(20) DEFAULT NULL,
  `edition` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sort_id` (`sid`),
  CONSTRAINT `sort_id` FOREIGN KEY (`sid`) REFERENCES `sorts` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of books
-- ----------------------------
INSERT INTO `books` VALUES ('1', 'C++程序设计', '1', '3', '陈小敏', '清华大学出版社', '第四版');
INSERT INTO `books` VALUES ('2', 'JAVA程序设计', '1', '10', '汤小洋', '清华大学出版社', '第二版');
INSERT INTO `books` VALUES ('3', '高等数学', '2', '9', '林海明', '清华大学出版社', '第一版');
INSERT INTO `books` VALUES ('4', '数据结构', '1', '5', '祝枝山', '南京大学出版社', '第二版');
INSERT INTO `books` VALUES ('5', '大学英语1', '4', '3', '李根强', '清华大学出版社', '第二版');
INSERT INTO `books` VALUES ('6', '大学英语3', '4', '5', '程燕', '清华大学出版社', '第二版');
INSERT INTO `books` VALUES ('7', '大学英语2', '4', '5', '罗丽渊', '广海大学出版社', '第五版');
INSERT INTO `books` VALUES ('8', '微积分', '2', '4', '周杰伦', '上海交通大学出版社', '第八版');
INSERT INTO `books` VALUES ('9', '唐诗宋词300首', '4', '5', '雪虎', '中国铁道出版社', '第七版');
INSERT INTO `books` VALUES ('10', '大学生心理健康', '5', '5', '卢本伟', '中国铁道出版社', '第十版');
INSERT INTO `books` VALUES ('11', '操作系统', '1', '3', '秋香', '邮电大学出版社', '第二版');
INSERT INTO `books` VALUES ('13', '大学英语4', '3', '5', '林耀东', '辽宁出版社', '第一版');
INSERT INTO `books` VALUES ('14', '应用文', '4', '5', '普营山', '辽宁出版社', '第四版');
INSERT INTO `books` VALUES ('15', 'SpringBoot快速开发入门教程', '1', '19', '汤小洋', '机械工业出版社', '第二版');
INSERT INTO `books` VALUES ('16', 'Vue.js 2.0全家桶教程', '1', '9', '唐伯虎', '机械工业出版社', '第四版');
INSERT INTO `books` VALUES ('17', 'Spring框架从入门到精通', '1', '0', '汤小洋', '南京大学出版社', '第一版');
INSERT INTO `books` VALUES ('18', 'MyBatis快速入门实战教程', '1', '19', '汤小洋', '机械工业出版社', '第三版');

-- ----------------------------
-- Table structure for borrows
-- ----------------------------
DROP TABLE IF EXISTS `borrows`;
CREATE TABLE `borrows` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `bid` int(11) DEFAULT NULL,
  `startTime` datetime DEFAULT NULL,
  `endTime` datetime DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`uid`),
  KEY `book_id` (`bid`),
  CONSTRAINT `book_id` FOREIGN KEY (`bid`) REFERENCES `books` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_id` FOREIGN KEY (`uid`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of borrows
-- ----------------------------
INSERT INTO `borrows` VALUES ('14', '2', '2', '2021-03-11 14:45:28', '2020-01-11 14:48:10', '1');
INSERT INTO `borrows` VALUES ('15', '2', '11', '2021-03-11 14:46:01', null, '1');
INSERT INTO `borrows` VALUES ('16', '3', '1', '2021-03-11 14:46:38', null, '1');
INSERT INTO `borrows` VALUES ('17', '3', '16', '2021-03-11 14:46:42', null, '1');
INSERT INTO `borrows` VALUES ('18', '2', '5', '2021-03-11 14:49:22', null, '1');
INSERT INTO `borrows` VALUES ('19', '2', '3', '2021-03-11 14:49:38', null, '0');

-- ----------------------------
-- Table structure for reserves
-- ----------------------------
DROP TABLE IF EXISTS `reserves`;
CREATE TABLE `reserves` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `bkid` int(11) DEFAULT NULL,
  `startTime` datetime DEFAULT NULL,
  `endTime` datetime DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `books_id2` (`bkid`),
  KEY `user_id2` (`uid`),
  CONSTRAINT `books_id2` FOREIGN KEY (`bkid`) REFERENCES `books` (`id`),
  CONSTRAINT `user_id2` FOREIGN KEY (`uid`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of reserves
-- ----------------------------

-- ----------------------------
-- Table structure for sorts
-- ----------------------------
DROP TABLE IF EXISTS `sorts`;
CREATE TABLE `sorts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sname` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sorts
-- ----------------------------
INSERT INTO `sorts` VALUES ('1', '计算机类');
INSERT INTO `sorts` VALUES ('2', '数学类');
INSERT INTO `sorts` VALUES ('3', '英语类');
INSERT INTO `sorts` VALUES ('4', '语文类');
INSERT INTO `sorts` VALUES ('5', '生活类');

-- ----------------------------
-- Table structure for sysadmin
-- ----------------------------
DROP TABLE IF EXISTS `sysadmin`;
CREATE TABLE `sysadmin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(20) DEFAULT NULL,
  `code` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sysadmin
-- ----------------------------
INSERT INTO `sysadmin` VALUES ('1', '超级管理员', 'admin', '123');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(20) DEFAULT NULL,
  `code` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('2', '张三', 'zhangsan', '123');
INSERT INTO `users` VALUES ('3', '李四', 'lisi', '123');
INSERT INTO `users` VALUES ('4', '王五', 'wangwu', '111111');
