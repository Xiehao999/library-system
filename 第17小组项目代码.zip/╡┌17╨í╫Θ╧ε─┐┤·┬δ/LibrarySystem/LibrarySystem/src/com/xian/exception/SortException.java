package com.xian.exception;

public class SortException extends Exception {

	public SortException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SortException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public SortException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public SortException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public SortException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
